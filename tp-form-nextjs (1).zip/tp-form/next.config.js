/** @type {import('next').NextConfig} */
const nextConfig = {
  // Increase body size limit for CV file uploads (default is 1mb)
  api: {
    bodyParser: {
      sizeLimit: '10mb',
    },
  },
}

module.exports = nextConfig
