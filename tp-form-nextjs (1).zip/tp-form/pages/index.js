import { useState, useEffect, useRef } from 'react'
import Head from 'next/head'
import Image from 'next/image'

export default function Home() {

  // ── MODAL STATE ──────────────────────────────────────────
  const [modal, setModal]               = useState('age')
  const [consentData, setConsentData]   = useState(false)
  const [consentFuture, setConsentFuture] = useState(false)
  const [consentErr, setConsentErr]     = useState('')
  const [consentDone, setConsentDone]   = useState(false)

  // ── FORM STATE ───────────────────────────────────────────
  const [form, setForm] = useState({
    fullName:'', email:'', phone:'', nationality:'',
    city:'', dob:'', language:'', otherLanguage:'',
    workType:'', startDate:'',
  })
  const [errors, setErrors]     = useState({})
  const [cvFile, setCvFile]     = useState(null)
  const [progress, setProgress] = useState(0)
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [touched, setTouched]   = useState({})
  const fileRef = useRef(null)

  // ── GA HELPER ────────────────────────────────────────────
  const track = (action, label, extra = {}) => {
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('event', action, { event_category:'TP Job Application', event_label:label, ...extra })
    }
  }

  // ── PAGE LOAD ────────────────────────────────────────────
  useEffect(() => {
    const p = new URLSearchParams(window.location.search)
    track('page_view', 'form_loaded', {
      referrer:     document.referrer || 'direct',
      utm_source:   p.get('utm_source')   || 'direct',
      utm_medium:   p.get('utm_medium')   || '',
      utm_campaign: p.get('utm_campaign') || '',
    })
  }, [])

  // ── PROGRESS BAR ─────────────────────────────────────────
  useEffect(() => {
    const req = ['fullName','email','phone','nationality','city','dob','language']
    const n = req.filter(k => form[k] && form[k].trim()).length
    setProgress(Math.round((n / req.length) * 100))
  }, [form])

  // ── MODAL HANDLERS ───────────────────────────────────────
  const confirmAge = () => { setModal('consent'); track('age_gate','passed_18_plus') }
  const denyAge    = () => { setModal('blocked'); track('age_gate','blocked_under_18') }

  const confirmConsent = () => {
    if (!consentData) { setConsentErr('Please tick the required box to continue.'); return }
    setModal(null); setConsentDone(true)
    track('consent_accepted','data_processing')
    if (consentFuture) track('future_contact_opted_in','yes')
    else               track('future_contact_opted_out','no')
  }
  const declineConsent = () => { setModal('blocked'); track('consent_declined','exited') }

  // ── FORM CHANGE ──────────────────────────────────────────
  const handleChange = e => {
    const { name, value } = e.target
    setForm(p => ({ ...p, [name]: value }))
    if (!touched[name]) { track('field_touched', name); setTouched(p => ({ ...p, [name]: true })) }
    if (name === 'language') track('language_selected', value)
  }

  // ── AGE CHECK ────────────────────────────────────────────
  const isOver18 = dob => {
    if (!dob) return false
    const t = new Date(), b = new Date(dob)
    const a = t.getFullYear() - b.getFullYear(), m = t.getMonth() - b.getMonth()
    return a > 18 || (a === 18 && (m > 0 || (m === 0 && t.getDate() >= b.getDate())))
  }

  // ── FILE TO BASE64 ───────────────────────────────────────
  // Converts the CV file in the browser before sending to /api/submit
  const fileToBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload  = () => resolve(reader.result.split(',')[1]) // strip data:...;base64,
    reader.onerror = reject
    reader.readAsDataURL(file)
  })

  // ── SUBMIT ───────────────────────────────────────────────
  // The form does NOT talk to Power Automate directly.
  // It sends everything to our own Next.js API route: /api/submit
  // That server-side function handles the PAD connection securely.
  const handleSubmit = async e => {
    e.preventDefault()
    track('apply_button_clicked','submit_attempted')

    // Validate
    const errs = {}
    if (!form.fullName.trim())    errs.fullName    = 'Please enter your full name.'
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
                                  errs.email       = 'Please enter a valid email.'
    if (!form.phone.trim())       errs.phone       = 'Please enter your phone number.'
    if (!form.nationality.trim()) errs.nationality = 'Please enter your nationality.'
    if (!form.city.trim())        errs.city        = 'Please enter your city.'
    if (!isOver18(form.dob))      errs.dob         = 'You must be at least 18 years old.'
    if (!form.language)           errs.language    = 'Please select a language.'

    if (Object.keys(errs).length > 0) {
      setErrors(errs)
      track('form_validation_failed','missing_fields')
      return
    }
    setErrors({})
    setSubmitting(true)

    const p = new URLSearchParams(window.location.search)

    // Convert CV to base64 if uploaded
    let cv_file_base64 = ''
    let cv_file_name   = ''
    let cv_file_type   = ''
    if (cvFile) {
      cv_file_base64 = await fileToBase64(cvFile)
      cv_file_name   = cvFile.name
      cv_file_type   = cvFile.type
    }

    // ── POST TO /api/submit (Next.js API route) ───────────
    // The API route lives at pages/api/submit.js
    // It receives this body, adds the PAD webhook URL from .env,
    // and forwards everything to Power Automate server-side.
    try {
      const res = await fetch('/api/submit', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name:                    form.fullName,
          email:                   form.email,
          phone:                   form.phone,
          nationality:             form.nationality,
          city:                    form.city,
          dob:                     form.dob,
          language:                form.language,
          other_language:          form.otherLanguage || '',
          work_type:               form.workType || '',
          start_date:              form.startDate || '',
          consent_data_processing: consentData,
          consent_future_contact:  consentFuture,
          utm_source:              p.get('utm_source')   || 'direct',
          utm_medium:              p.get('utm_medium')   || '',
          utm_campaign:            p.get('utm_campaign') || '',
          page_url:                window.location.href,
          cv_file_base64,
          cv_file_name,
          cv_file_type,
        }),
      })

      if (res.ok) {
        track('form_submitted', form.language, {
          language: form.language, has_cv: !!cvFile,
          consent_future: consentFuture ? 'yes' : 'no',
          utm_source: p.get('utm_source') || 'direct',
        })
        if (consentFuture) track('candidate_wants_future_contact', form.language)
        window.gtag?.('event','generate_lead',{ currency:'MYR', value:1, language:form.language })
        setSubmitted(true)
        setProgress(100)
        window.scrollTo({ top:0, behavior:'smooth' })
      } else {
        track('submit_error','api_failed')
        alert('Something went wrong. Please try again.')
      }
    } catch (err) {
      track('submit_error', err.message)
      alert('Something went wrong. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  const gaId = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID

  return (
    <>
      <Head>
        <title>TPMY Careers – Join Our Team</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, viewport-fit=cover" />
        <script async src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`} />
        <script dangerouslySetInnerHTML={{ __html: `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${gaId}',{page_title:'TPMY Careers',page_location:window.location.href});` }} />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </Head>

      <style>{`
        :root{--slate:#4B4C6A;--slate-dark:#35364d;--pink:#ff0082;--bg:#eae7e4;--card:#fff;--warm:#f5f3f0;--text:#1a1816;--mid:#5a5651;--muted:#918e81;--border:#e2dfd9;--green:#0a6e45;--green-bg:#eaf6f0;--r8:8px;--r12:12px;--r16:16px;}
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;padding-bottom:80px;}
        .overlay{position:fixed;inset:0;background:rgba(26,24,22,.72);backdrop-filter:blur(8px);z-index:200;display:flex;align-items:center;justify-content:center;padding:20px;}
        .modal{background:var(--card);border-radius:var(--r16);width:100%;max-width:500px;box-shadow:0 40px 100px rgba(26,24,22,.28);overflow:hidden;}
        .modal-head{background:var(--slate);padding:22px 28px;display:flex;align-items:center;gap:14px;}
        .modal-head img{height:26px;filter:invert(1);mix-blend-mode:screen;}
        .modal-head-label{color:rgba(255,255,255,.6);font-size:11px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;}
        .modal-body{padding:26px 28px 8px;}
        .modal-icon{font-size:28px;margin-bottom:12px;}
        .modal-title{font-size:20px;font-weight:700;margin-bottom:8px;}
        .modal-text{font-size:14px;color:var(--mid);line-height:1.72;}
        .data-box{background:var(--warm);border:1px solid var(--border);border-radius:var(--r8);padding:16px;margin-top:14px;font-size:13px;color:var(--mid);line-height:1.78;}
        .data-box h4{color:var(--slate);font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;margin-bottom:4px;margin-top:12px;}
        .data-box h4:first-child{margin-top:0;}
        .data-box ul{padding-left:16px;}
        .data-box li{margin-bottom:2px;}
        .modal-checks{padding:14px 28px 4px;display:flex;flex-direction:column;gap:9px;}
        .check-card{display:flex;align-items:flex-start;gap:12px;background:var(--warm);border:1.5px solid var(--border);border-radius:var(--r8);padding:13px 14px;cursor:pointer;transition:border-color .15s;}
        .check-card:hover{border-color:var(--slate);}
        .check-card input{width:17px;height:17px;min-width:17px;margin-top:2px;cursor:pointer;accent-color:var(--slate);}
        .check-card label{font-size:13px;color:var(--text);margin:0;cursor:pointer;line-height:1.55;}
        .badge{display:inline-block;font-size:10px;font-weight:700;padding:2px 7px;border-radius:20px;margin-left:5px;}
        .badge-req{background:#e8e6f0;color:var(--slate);}
        .badge-opt{background:#ece9e7;color:var(--muted);}
        .modal-err{font-size:12px;color:#b5003a;padding:4px 28px 0;min-height:18px;}
        .modal-footer{padding:14px 28px 26px;display:flex;flex-direction:column;gap:8px;}
        .btn-slate{width:100%;background:var(--slate);color:#fff;border:none;border-radius:var(--r8);padding:14px 20px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:600;cursor:pointer;letter-spacing:.01em;transition:background .15s;}
        .btn-slate:hover{background:var(--slate-dark);}
        .btn-slate:disabled{background:#d4d2ca;color:var(--muted);cursor:not-allowed;}
        .btn-ghost{width:100%;background:transparent;border:none;color:var(--muted);font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;cursor:pointer;padding:8px;text-decoration:underline;}
        .blocked-inner{padding:36px 28px;text-align:center;}
        .site-header{background:var(--slate);position:sticky;top:0;z-index:10;box-shadow:0 2px 20px rgba(26,24,22,.3);}
        .header-inner{max-width:900px;margin:0 auto;padding:0 32px;height:72px;display:flex;align-items:center;justify-content:space-between;}
        .header-left{display:flex;align-items:center;gap:18px;}
        .header-logo{height:34px;object-fit:contain;filter:invert(1);mix-blend-mode:screen;}
        .header-divider{width:1px;height:32px;background:rgba(255,255,255,.2);}
        .header-label{color:rgba(255,255,255,.55);font-size:12px;font-weight:500;letter-spacing:.04em;text-transform:uppercase;}
        .header-badge{background:var(--pink);color:#fff;font-size:11px;font-weight:700;padding:5px 12px;border-radius:20px;letter-spacing:.04em;text-transform:uppercase;}
        .header-country{color:rgba(255,255,255,.5);font-size:12px;}
        .progress-bar{height:3px;background:rgba(255,255,255,.1);}
        .progress-fill{height:100%;background:var(--pink);transition:width .4s ease;}
        .hero{background:var(--slate-dark);padding:52px 32px 48px;color:#fff;position:relative;overflow:hidden;}
        .hero-eyebrow{display:flex;align-items:center;gap:10px;margin-bottom:20px;}
        .hero-eyebrow-line{width:24px;height:2px;background:var(--pink);}
        .hero-eyebrow-text{font-size:11px;font-weight:700;color:rgba(255,255,255,.6);letter-spacing:.1em;text-transform:uppercase;}
        .hero-title{font-size:36px;font-weight:300;line-height:1.15;margin-bottom:6px;}
        .hero-title strong{font-weight:700;}
        .hero-sub{font-size:15px;color:rgba(255,255,255,.65);line-height:1.7;max-width:520px;margin-bottom:28px;}
        .hero-tags{display:flex;flex-wrap:wrap;gap:8px;}
        .hero-tag{font-size:12px;font-weight:500;color:rgba(255,255,255,.7);border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.05);padding:5px 13px;border-radius:20px;}
        .container{max-width:640px;margin:0 auto;padding:32px 20px 0;}
        .consent-note{display:flex;align-items:flex-start;gap:12px;background:#eef0f8;border:1px solid #c2c7d4;border-radius:var(--r12);padding:14px 16px;font-size:13px;color:var(--slate);line-height:1.6;margin-bottom:24px;}
        .form-card{background:var(--card);border:1px solid var(--border);border-radius:var(--r16);margin-bottom:12px;overflow:hidden;box-shadow:0 2px 12px rgba(26,24,22,.06);}
        .card-head{padding:16px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;background:#faf9f7;}
        .card-icon{font-size:16px;}
        .card-title{font-size:13px;font-weight:700;color:var(--text);}
        .card-opt{font-size:11px;color:var(--muted);font-weight:400;margin-left:4px;}
        .card-body{padding:20px 22px;}
        .field{margin-bottom:16px;}
        .field:last-child{margin-bottom:0;}
        .field-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
        .field-label{display:block;font-size:11px;font-weight:700;color:var(--muted);margin-bottom:6px;letter-spacing:.06em;text-transform:uppercase;}
        .req{color:var(--pink);margin-left:2px;}
        input[type=text],input[type=email],input[type=tel],input[type=date],select{width:100%;font-family:'Plus Jakarta Sans',sans-serif;font-size:16px;color:var(--text);background:var(--warm);border:1.5px solid var(--border);border-radius:var(--r8);padding:12px 14px;transition:border-color .15s;appearance:none;-webkit-appearance:none;outline:none;}
        input::placeholder{color:#b8b2a8;font-size:14px;}
        input:focus,select:focus{border-color:var(--slate);box-shadow:0 0 0 3px rgba(75,76,106,.13);background:#fff;}
        input.err,select.err{border-color:#b5003a;}
        .field-error{font-size:12px;color:#b5003a;margin-top:5px;}
        .field-hint{font-size:12px;color:var(--muted);margin-top:5px;}
        select{background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23918e81' stroke-width='1.5' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center;background-color:var(--warm);padding-right:38px;cursor:pointer;}
        .file-zone{border:2px dashed var(--border);border-radius:var(--r12);padding:22px 18px;text-align:center;cursor:pointer;transition:all .15s;}
        .file-zone:hover{border-color:var(--slate);background:#eef0f8;}
        .file-zone-icon{font-size:22px;margin-bottom:7px;}
        .file-zone-label{font-size:13px;font-weight:600;color:var(--text);}
        .file-zone-sub{font-size:12px;color:var(--muted);margin-top:3px;}
        .file-zone-name{font-size:12px;color:var(--green);margin-top:8px;font-weight:700;}
        .submit-btn{width:100%;background:var(--slate);color:#fff;border:none;border-radius:var(--r12);padding:17px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:700;cursor:pointer;letter-spacing:.02em;transition:background .15s;}
        .submit-btn:hover{background:var(--slate-dark);}
        .submit-btn:disabled{background:#d4d2ca;cursor:not-allowed;}
        .submit-note{font-size:12px;color:var(--muted);text-align:center;margin-top:10px;line-height:1.6;}
        .success-screen{text-align:center;padding:64px 24px;}
        .success-ring{width:70px;height:70px;border-radius:50%;background:var(--green-bg);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:30px;}
        .success-title{font-size:26px;font-weight:700;margin-bottom:10px;}
        .success-body{font-size:15px;color:var(--mid);line-height:1.75;}
        .site-footer{background:var(--slate-dark);color:rgba(255,255,255,.55);margin-top:64px;}
        .footer-top{border-bottom:1px solid rgba(255,255,255,.08);padding:40px 32px 36px;}
        .footer-top-inner{max-width:900px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr 1fr;gap:32px;}
        .footer-logo{height:30px;object-fit:contain;filter:invert(1);mix-blend-mode:screen;margin-bottom:12px;display:block;}
        .footer-tagline{font-size:12px;color:rgba(255,255,255,.4);line-height:1.6;}
        .footer-col-title{font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.35);margin-bottom:12px;}
        .footer-links{list-style:none;display:flex;flex-direction:column;gap:8px;}
        .footer-links a{color:rgba(255,255,255,.55);font-size:13px;text-decoration:none;}
        .footer-contact-line{font-size:13px;color:rgba(255,255,255,.55);margin-bottom:6px;}
        .footer-contact-line a{color:rgba(255,255,255,.7);text-decoration:none;}
        .footer-bottom{padding:18px 32px;}
        .footer-bottom-inner{max-width:900px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;}
        .footer-copy{font-size:12px;color:rgba(255,255,255,.3);}
        .footer-langs{display:flex;gap:6px;flex-wrap:wrap;}
        .footer-lang{font-size:11px;color:rgba(255,255,255,.3);border:1px solid rgba(255,255,255,.1);padding:3px 9px;border-radius:20px;}
        @media(max-width:540px){.field-row{grid-template-columns:1fr;}.hero{padding:36px 20px 32px;}.hero-title{font-size:26px;}.header-inner{padding:0 20px;}.header-badge,.header-country{display:none;}.footer-top-inner{grid-template-columns:1fr;gap:24px;}.footer-top{padding:32px 20px 28px;}.footer-bottom{padding:16px 20px;}}
      `}</style>

      {/* AGE GATE */}
      {modal === 'age' && (
        <div className="overlay">
          <div className="modal">
            <div className="modal-head">
              <img src="/tp-logo.png" alt="TP" />
              <span className="modal-head-label">Careers at Teleperformance</span>
            </div>
            <div className="modal-body">
              <div className="modal-icon">👋</div>
              <div className="modal-title">Welcome! One quick check</div>
              <div className="modal-text">We're excited you're interested in joining the TP team.<br /><br />This role requires applicants to be <strong>18 years of age or older</strong>. Please confirm to continue.</div>
            </div>
            <div className="modal-footer">
              <button className="btn-slate" onClick={confirmAge}>Yes, I'm 18 or older — let's go →</button>
              <button className="btn-ghost" onClick={denyAge}>I am under 18</button>
            </div>
          </div>
        </div>
      )}

      {/* CONSENT */}
      {modal === 'consent' && (
        <div className="overlay">
          <div className="modal">
            <div className="modal-head">
              <img src="/tp-logo.png" alt="TP" />
              <span className="modal-head-label">Data &amp; Privacy</span>
            </div>
            <div className="modal-body">
              <div className="modal-icon">🔒</div>
              <div className="modal-title">How we handle your information</div>
              <div className="modal-text">
                We take your privacy seriously. Here's exactly what we collect and why.
                <div className="data-box">
                  <h4>What we collect</h4>
                  <ul><li>Personal details: name, email, phone, nationality, city</li><li>Language proficiency and availability</li><li>Documents you choose to share (CV)</li></ul>
                  <h4>How we use it</h4>
                  <ul><li>To assess your application</li><li>To create a candidate profile in our recruitment system</li><li>To contact you about this or future matching roles</li></ul>
                  <h4>Your rights — PDPA 2010</h4>
                  Email <a href="mailto:privacy@teleperformance.com" style={{color:'var(--slate)'}}>privacy@teleperformance.com</a> to access, correct or delete your data.
                </div>
              </div>
            </div>
            <div className="modal-checks">
              <div className="check-card">
                <input type="checkbox" id="cd" checked={consentData} onChange={e => { setConsentData(e.target.checked); setConsentErr('') }} />
                <label htmlFor="cd">I consent to Teleperformance collecting and processing my personal data to evaluate my application and create a candidate profile on my behalf. <span className="badge badge-req">Required</span></label>
              </div>
              <div className="check-card">
                <input type="checkbox" id="cf" checked={consentFuture} onChange={e => setConsentFuture(e.target.checked)} />
                <label htmlFor="cf">I'd like to be contacted about future roles that match my profile. <span className="badge badge-opt">Optional</span></label>
              </div>
            </div>
            {consentErr && <div className="modal-err">{consentErr}</div>}
            <div className="modal-footer">
              <button className="btn-slate" onClick={confirmConsent} disabled={!consentData}>I agree — take me to the form →</button>
              <button className="btn-ghost" onClick={declineConsent}>I do not consent — exit</button>
            </div>
          </div>
        </div>
      )}

      {/* BLOCKED */}
      {modal === 'blocked' && (
        <div className="overlay">
          <div className="modal">
            <div className="modal-head"><img src="/tp-logo.png" alt="TP" /></div>
            <div className="blocked-inner">
              <div style={{fontSize:36,marginBottom:14}}>🚫</div>
              <div style={{fontSize:19,fontWeight:700,marginBottom:8}}>Unable to proceed</div>
              <div style={{fontSize:14,color:'var(--mid)',lineHeight:1.7}}>This position requires applicants to be <strong>18 or older</strong> and to consent to data processing.<br /><br />Thank you for your interest — we hope to welcome you in the future!</div>
            </div>
          </div>
        </div>
      )}

      {/* HEADER */}
      <header className="site-header">
        <div className="header-inner">
          <div className="header-left">
            <img className="header-logo" src="/tp-logo.png" alt="TPMY" />
            <div className="header-divider" />
            <span className="header-label">TPMY Careers</span>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:12}}>
            <span className="header-country">🇲🇾 Malaysia</span>
            <span className="header-badge">Now Hiring</span>
          </div>
        </div>
      </header>
      <div className="progress-bar"><div className="progress-fill" style={{width:`${progress}%`}} /></div>

      {/* HERO */}
      <div className="hero">
        <div style={{maxWidth:900,margin:'0 auto',position:'relative',zIndex:1}}>
          <div className="hero-eyebrow"><div className="hero-eyebrow-line" /><span className="hero-eyebrow-text">Multilingual Roles · Malaysia</span></div>
          <div className="hero-title">We'd love to have<br /><strong>you on the team</strong></div>
          <div className="hero-sub">Fill in your details — it takes less than 3 minutes. We'll review your profile and be in touch very soon.</div>
          <div className="hero-tags">
            {['Mandarin 普通话','Cantonese 广东话','Japanese 日本語','Korean 한국어','Malay'].map(t => <span key={t} className="hero-tag">{t}</span>)}
          </div>
        </div>
      </div>

      {/* FORM */}
      <div className="container">
        {submitted ? (
          <div className="success-screen">
            <div className="success-ring">🎉</div>
            <div className="success-title">Application received!</div>
            <div className="success-body">Thank you for applying to Teleperformance Malaysia.<br />Our team will review your profile and reach out shortly.<br /><br /><span style={{color:'var(--muted)',fontSize:13}}>Keep an eye on your inbox and WhatsApp!</span></div>
          </div>
        ) : (
          <>
            {consentDone && (
              <div className="consent-note">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={{flexShrink:0,marginTop:1}}><circle cx="8" cy="8" r="7.25" stroke="#4B4C6A" strokeWidth="1.5"/><path d="M8 5v3.5M8 11h.01" stroke="#4B4C6A" strokeWidth="1.5" strokeLinecap="round"/></svg>
                <span>Consent recorded. Submitting creates a candidate profile on your behalf. <a href="mailto:privacy@teleperformance.com" style={{color:'var(--slate)',fontWeight:600}}>Questions?</a></span>
              </div>
            )}
            <form onSubmit={handleSubmit} noValidate>
              <div className="form-card">
                <div className="card-head"><span className="card-icon">👤</span><span className="card-title">Personal Information</span></div>
                <div className="card-body">
                  <div className="field">
                    <label className="field-label" htmlFor="fullName">Full name <span className="req">*</span></label>
                    <input type="text" id="fullName" name="fullName" autoComplete="name" placeholder="e.g. Muhammad Amirul bin Abdullah" value={form.fullName} onChange={handleChange} className={errors.fullName?'err':''} />
                    {errors.fullName && <div className="field-error">{errors.fullName}</div>}
                  </div>
                  <div className="field-row">
                    <div className="field">
                      <label className="field-label" htmlFor="email">Email <span className="req">*</span></label>
                      <input type="email" id="email" name="email" autoComplete="email" placeholder="e.g. amirul@gmail.com" value={form.email} onChange={handleChange} className={errors.email?'err':''} />
                      {errors.email && <div className="field-error">{errors.email}</div>}
                    </div>
                    <div className="field">
                      <label className="field-label" htmlFor="phone">Phone <span className="req">*</span></label>
                      <input type="tel" id="phone" name="phone" autoComplete="tel" placeholder="e.g. +60 12-345 6789" value={form.phone} onChange={handleChange} className={errors.phone?'err':''} />
                      {errors.phone && <div className="field-error">{errors.phone}</div>}
                    </div>
                  </div>
                  <div className="field-row">
                    <div className="field">
                      <label className="field-label" htmlFor="nationality">Nationality <span className="req">*</span></label>
                      <input type="text" id="nationality" name="nationality" autoComplete="country-name" placeholder="e.g. Malaysian" value={form.nationality} onChange={handleChange} className={errors.nationality?'err':''} />
                      {errors.nationality && <div className="field-error">{errors.nationality}</div>}
                    </div>
                    <div className="field">
                      <label className="field-label" htmlFor="city">City <span className="req">*</span></label>
                      <input type="text" id="city" name="city" autoComplete="address-level2" placeholder="e.g. Kuala Lumpur" value={form.city} onChange={handleChange} className={errors.city?'err':''} />
                      {errors.city && <div className="field-error">{errors.city}</div>}
                    </div>
                  </div>
                  <div className="field">
                    <label className="field-label" htmlFor="dob">Date of birth <span className="req">*</span></label>
                    <input type="date" id="dob" name="dob" autoComplete="bday" value={form.dob} onChange={handleChange} className={errors.dob?'err':''} />
                    <div className="field-hint">You must be 18 or older to apply.</div>
                    {errors.dob && <div className="field-error">{errors.dob}</div>}
                  </div>
                  <div className="field">
                    <label className="field-label" htmlFor="language">Language proficiency <span className="req">*</span></label>
                    <select id="language" name="language" value={form.language} onChange={handleChange} className={errors.language?'err':''}>
                      <option value="" disabled>Select your language</option>
                      <option value="Mandarin">Mandarin (普通话)</option>
                      <option value="Cantonese">Cantonese (广东话)</option>
                      <option value="Japanese">Japanese (日本語)</option>
                      <option value="Korean">Korean (한국어)</option>
                      <option value="Malay">Malay (Bahasa Melayu)</option>
                      <option value="Other">Other</option>
                    </select>
                    {errors.language && <div className="field-error">{errors.language}</div>}
                    {form.language === 'Other' && (
                      <input type="text" name="otherLanguage" placeholder="Please specify" value={form.otherLanguage} onChange={handleChange} style={{marginTop:10}} />
                    )}
                  </div>
                </div>
              </div>

              <div className="form-card">
                <div className="card-head"><span className="card-icon">📅</span><span className="card-title">Availability <span className="card-opt">— optional</span></span></div>
                <div className="card-body">
                  <div className="field-row">
                    <div className="field">
                      <label className="field-label" htmlFor="workType">Work preference</label>
                      <select id="workType" name="workType" value={form.workType} onChange={handleChange}>
                        <option value="">Any</option>
                        <option value="Full-time">Full-time</option>
                        <option value="Part-time">Part-time</option>
                        <option value="Contract">Contract</option>
                      </select>
                    </div>
                    <div className="field">
                      <label className="field-label" htmlFor="startDate">Earliest start date</label>
                      <input type="date" id="startDate" name="startDate" value={form.startDate} onChange={handleChange} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="form-card">
                <div className="card-head"><span className="card-icon">📄</span><span className="card-title">CV / Resume <span className="card-opt">— optional</span></span></div>
                <div className="card-body">
                  <div className="file-zone" onClick={() => fileRef.current?.click()}>
                    <input type="file" ref={fileRef} accept=".pdf,.doc,.docx" style={{display:'none'}} onChange={e => { if(e.target.files[0]){ setCvFile(e.target.files[0]); track('cv_uploaded', e.target.files[0].name.split('.').pop()) }}} />
                    <div className="file-zone-icon">📎</div>
                    <div className="file-zone-label">Click to upload your CV</div>
                    <div className="file-zone-sub">PDF, DOC or DOCX · max 5MB</div>
                    {cvFile && <div className="file-zone-name">✓ {cvFile.name}</div>}
                  </div>
                </div>
              </div>

              <div style={{marginTop:8}}>
                <button type="submit" className="submit-btn" disabled={submitting}>
                  {submitting ? 'Submitting...' : 'Submit My Application →'}
                </button>
                <div className="submit-note">Fields marked <span style={{color:'var(--pink)'}}>*</span> are required. By submitting, you confirm all information is accurate and you are 18 or older.</div>
              </div>
            </form>
          </>
        )}
      </div>

      {/* FOOTER */}
      <footer className="site-footer">
        <div className="footer-top">
          <div className="footer-top-inner">
            <div>
              <img className="footer-logo" src="/tp-logo.png" alt="Teleperformance" />
              <div className="footer-tagline">Global leader in digital business services. Now hiring multilingual talent in Malaysia.</div>
            </div>
            <div>
              <div className="footer-col-title">Legal</div>
              <ul className="footer-links">
                <li><a href="mailto:privacy@teleperformance.com">Privacy Policy</a></li>
                <li><a href="mailto:privacy@teleperformance.com">PDPA Notice</a></li>
                <li><a href="mailto:privacy@teleperformance.com">Data Request</a></li>
              </ul>
            </div>
            <div>
              <div className="footer-col-title">Contact</div>
              <div className="footer-contact-line">Questions?<br /><a href="mailto:careers.my@teleperformance.com">careers.my@teleperformance.com</a></div>
              <div className="footer-contact-line" style={{marginTop:8}}>Privacy?<br /><a href="mailto:privacy@teleperformance.com">privacy@teleperformance.com</a></div>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <div className="footer-bottom-inner">
            <div className="footer-copy">© 2025 Teleperformance. All rights reserved. | TPMY Careers</div>
            <div className="footer-langs">
              {['普通话','广东话','日本語','한국어','BM'].map(l => <span key={l} className="footer-lang">{l}</span>)}
            </div>
          </div>
        </div>
      </footer>
    </>
  )
}
