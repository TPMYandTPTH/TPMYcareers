// ════════════════════════════════════════════════════════════
// pages/api/submit.js — Next.js API Route
//
// This is the actual Next.js part.
// The browser sends the form data + CV file HERE first.
// This server-side function then:
//   1. Converts the CV file to base64
//   2. Builds the full payload
//   3. POSTs to Power Automate (PAD_WEBHOOK_URL from .env)
//
// Why server-side?
//   - PAD_WEBHOOK_URL never reaches the browser (secure)
//   - File processing happens on the server (reliable)
//   - Power Automate receives everything in one clean request
// ════════════════════════════════════════════════════════════

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '10mb', // allow CV files up to 10mb
    },
  },
}

export default async function handler(req, res) {
  // Only accept POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const {
      name, email, phone, nationality, city, dob,
      language, other_language, work_type, start_date,
      consent_data_processing, consent_future_contact,
      utm_source, utm_medium, utm_campaign, page_url,
      // CV comes as base64 from the browser
      cv_file_base64,
      cv_file_name,
      cv_file_type,
    } = req.body

    // ── BUILD PAYLOAD ──────────────────────────────────────
    // This is the full JSON sent to Power Automate.
    // In PAD: trigger = "When an HTTP request is received"
    // PAD then:
    //   1. Creates the file in SharePoint Documents using cv_file_base64
    //   2. Creates the candidate row in the SharePoint list
    const payload = {
      // Candidate info
      name,
      email,
      phone,
      nationality,
      city,
      dob,
      language,
      other_language:          other_language || '',
      work_type:               work_type || '',
      start_date:              start_date || '',

      // CV file — base64 encoded
      // Power Automate: use "Create file" action in SharePoint
      // Set file content = base64ToBinary(cv_file_base64)
      has_cv:                  !!cv_file_base64,
      cv_file_name:            cv_file_name || '',
      cv_file_type:            cv_file_type || '',
      cv_file_base64:          cv_file_base64 || '',

      // Consent
      consent_data_processing: consent_data_processing,
      consent_future_contact:  consent_future_contact,

      // Metadata
      submitted_at:            new Date().toISOString(),
      page_url:                page_url || '',
      utm_source:              utm_source || 'direct',
      utm_medium:              utm_medium || '',
      utm_campaign:            utm_campaign || '',
      source:                  'tpmy_careers_form',
    }

    // ── POST TO POWER AUTOMATE ─────────────────────────────
    // PAD_WEBHOOK_URL lives in .env — never exposed to browser
    const padResponse = await fetch(process.env.PAD_WEBHOOK_URL, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(payload),
    })

    if (!padResponse.ok) {
      console.error('PAD webhook error:', padResponse.status, await padResponse.text())
      return res.status(500).json({ error: 'Failed to send to Power Automate' })
    }

    // ── SUCCESS ────────────────────────────────────────────
    return res.status(200).json({ success: true })

  } catch (error) {
    console.error('Submit API error:', error)
    return res.status(500).json({ error: 'Internal server error' })
  }
}
