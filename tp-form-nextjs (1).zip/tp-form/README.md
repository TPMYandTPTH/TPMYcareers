# TPMY Careers — Next.js

## Architecture

```
Browser → /api/submit (Next.js API Route) → Power Automate → SharePoint
```

**Why API route?**
- PAD webhook URL never reaches the browser (secure)
- CV file converted to base64 server-side
- Power Automate receives everything in one clean request

## Env vars

| Variable | Where used |
|---|---|
| `PAD_WEBHOOK_URL` | Server only (pages/api/submit.js) |
| `NEXT_PUBLIC_GA_MEASUREMENT_ID` | Browser (GA4 tracking) |

## Power Automate payload

```json
{
  "name": "Ahmad",
  "email": "ahmad@gmail.com",
  "phone": "60-123",
  "nationality": "Malaysian",
  "city": "KL",
  "dob": "1995-01-01",
  "language": "Mandarin",
  "other_language": "",
  "work_type": "Full-time",
  "start_date": "2025-04-01",
  "has_cv": true,
  "cv_file_name": "Ahmad_CV.pdf",
  "cv_file_type": "application/pdf",
  "cv_file_base64": "JVBERi0xLjQg...",
  "consent_data_processing": true,
  "consent_future_contact": true,
  "submitted_at": "2025-03-19T08:42:11.000Z",
  "page_url": "https://tpmy.vercel.app?utm_source=whatsapp",
  "utm_source": "whatsapp",
  "utm_medium": "outreach",
  "utm_campaign": "mandarin_b1",
  "source": "tpmy_careers_form"
}
```

## In Power Automate

Add these steps after the HTTP trigger:
1. **Create file** (SharePoint) — use `cv_file_name` and base64ToBinary(`cv_file_base64`)
2. **Create item** (SharePoint list) — map all other fields

## Deploy

```bash
npm install
npm run dev          # test locally at localhost:3000
vercel --prod        # deploy
```

Add env vars in Vercel dashboard → Settings → Environment Variables.
